export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

/**
 * Sem as duas variaveis o cliente do Supabase lanca na hora de ser criado.
 * Como o middleware roda em toda rota, isso derrubava o site inteiro com
 * MIDDLEWARE_INVOCATION_FAILED. Agora o app degrada: diz o que falta.
 */
export const supabaseConfigurado = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
